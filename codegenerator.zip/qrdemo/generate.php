<?php

require "vendor/autoload.php";

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Label\Label;
use Endroid\QrCode\Label\Alignment\LabelAlignmentLeft;
use Endroid\QrCode\Logo\Logo;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Endroid\QrCode\Label\Alignment\LabelAlignmentCenter;

$text = $_POST["text"];

$qr_code = QrCode::create($text)
                 ->setSize(600)
                 ->setMargin(40)
                 ->setForegroundColor(new Color(86,130,3))
                 ->setBackgroundColor(new Color(249,255,227))
                 ->setErrorCorrectionLevel(new ErrorCorrectionLevelHigh);


$label = Label::create("")  
              ->setTextColor(new Color(107,142,35))
              ->setAlignment(new LabelAlignmentCenter);

$logo = Logo::create("RGS.png")
            ->setResizeToWidth(250);

$writer = new PngWriter;

$result = $writer->write($qr_code, logo: $logo, label: $label);

// Output the QR code image to the browser
header("Content-Type: " . $result->getMimeType());

echo $result->getString();

// Save the image to a file
$result->saveToFile("qrcode.png");

$path = "image";